CyberArk Automation Suite Readme

This suite contains a collection of helper scripts written in PowerShell to automate frequent CyberArk operations.

All direct communication with the CyberArk API is made with the 'psPAS' PowerShell module, available on GitHub.

Getting Started:
1. Unzip the contents of the Automation Suite to a directory.
2. Open config.ps1 in your text editor of choice. Update the values to match your environment.
    a) The config file contains a safe name evaluation Regex. To allow any safe name to be created, update the Regex to: ".*"
3. Right click 'TPAS.ps1' and select "Run With Powershell"

Sample Safe and Account Import Files are contained in the "Samples" folder.
All Logs will be written to the directory you unzipped the files to.
