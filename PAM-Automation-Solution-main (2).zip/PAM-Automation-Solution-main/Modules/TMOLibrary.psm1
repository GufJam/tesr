function Initialize-TMOSafeName {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [hashtable]$config
    )


    do {
        $safeName = ""
        Write-Host -ForegroundColor Green "Collecting Information To Create Safe"
        $segments = @("NT", "TC", "BL", "SNT", "STC", "BC")
        $environments = @("P", "T", "D", "L", "S")
        Write-Host -ForegroundColor Green "Select The Business Segment For The Safe"
        $segment = Menu -menuItems $segments
        do {
            if ($null -ne $apmid) {
                Write-Host -ForegroundColor Red "Invalid APMID. It Must be 7 digits."
            }
            $apmid = Read-Host "Please Enter the APMID" 
            if ($apmid -match "^[0-9]{7}$") {
                break
            }
        }
        while ($true)

        Write-Host -ForegroundColor Green "Select The Environment For The Safe"
        $environment = Menu -menuItems $environments

        do {
            if ($null -ne $desc) {
                Write-Host "Invalid Safe Description."
            }
            $desc = Read-Host "Please Enter the Short Safe Description. It must not contain special characters and must be between 1 and 16 characters long." 
            if ($desc -notmatch ".*(\\|\/|:|\*|<|>|`"|\.|\||^\s).*" -and $desc.Length -le 16 -and $desc.Length -gt 0) {
                break
            }
        }
        while ($true)

        $safeName = "$($segment)_$($apmid)$($environment)_$($desc)"

        Write-Host -ForegroundColor Green "Continue With Safe Name $($safeName)?"
        $continue = Menu "Y", "N"
        if ($continue -eq "Y") {
            break
        }
        else {
            Remove-Variable safeName,desc,apmid
        }
    }
    while ($true)

    Write-Host -ForegroundColor Green "Use The Default Managing CPM?"
    $cpmSelection = Menu -menuItems $config.AvailableCPMUsers

    Write-Host -ForegroundColor Green "Keep The Safe Creator As Safe Member?"
    $keepSafeCreator = Menu "Y", "N"

    do {
        if ($null -ne $longdesc) {
            Write-Host "Invalid Safe Description. It Must be less than 50 characters long. (Optional)"
        }
        $longdesc = Read-Host "Please Enter the Long Safe Description. Must be 50 or less characters. (Optional)" 
        if ($longdesc.Length -lt 51) {
            break
        }
    }
    while ($true)
    try {
        $SafeValue = $null
        $SafeValue = Assert-CYBAUTOSafeName -safeName $SafeName -config $config 
        if($null -eq $SafeValue){
            continue
        }
            
        $SafeValue|New-CYBAUTOSafeSingle -Members $config.DefaultSafeMembers -managingCPM $cpmSelection -KeepSafeCreatorAsMember:$($keepSafeCreator -eq "Y") -NumberOfVersionsRetention $config.DefaultVersionRetention -Description $longdesc >> $global:logFileName
        $details = "Created Safe $safeName"
    }
    catch {
        $_ >> $global:logFileName
        $details = "Unable to Create Safe $safeName" 
        Write-Host -ForegroundColor Red $details
        Write-Host -ForegroundColor Red $_
    }
    finally {
        [LogEvent]::new("AddSingleSafe", $details) | Export-Csv $global:reportFileName -NoTypeInformation -Append
    }
}
