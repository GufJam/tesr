$menuItems = [ordered] @{
    "Safe Management"    = @{
        "Create Single Safe"  = "Initialize-TMOSafeName"
        "Create New Safes" = "Import-CYBAUTOSafesCSV"
        "Delete Safes" = "Remove-SafesBulk"
        "Update Safes" = "Update-SafesBulk"
        "Add Safe Members" = "Add-SafeMemebersList"
        "Update Safe Members" = "Update-SafeMemebersList"
        "Remove Safe Members" = "Remove-SafeMembersBulk"
        "Export All Safes" = "Export-SafeReport"
        "Export Safe Members and Permissions" = "Export-SafeMemebersList"
        "Export Safes by Platform Name" = "Export-PlatformSafeLists"
        "Archive Safes" = "Set-SafeArchive"
    }
    "Account Management" = @{
        "On-board Accounts"       = "Import-CYBAUTOAccountsCSV"  
        "Update Accounts" = "Set-AccountsBulk"
        "Delete Accounts" = "Remove-AccountsbyID"
        "Create Account Groups" = "Import-CYBAUTOAccountGroupsCSV"
        "Export Accounts" = "Export-AccountsListReport"
        "Verify Account Password" = "Invoke-CredentialsVerifications"
        "Change Account Password" = "Invoke-ImmediateChangeCreds"
        "Reconcile Account Password" = "Invoke-ReconcileCredentials"
        "Export Account Groups by SafeName" = "Export-AccountGroupsReport"
        "Export Account Group Members by Group Name" = "Export-AccountGroupsMemebrs"
        "Add Account to Account Group" = "Add-AccountGroupMembers"
        "Delete Account from Account Group" = "Remove-AccountGroupMembers"
        "Link Accounts" = "Set-LinkedAccountsList"
        "Unlink Accounts" = "Set-UnlinkAccountsList"
    }
    "Platform Management" = @{
        "Export Platform Properties" = "Export-CYBAUTOPlatformProperties"
        "Import Platforms" = "Import-PlatformsZips"
        "Export Platforms" = "Export-PlatformsZips"
    }
    "Run Tests"          = @{
        "Test PSMs" = "Test-CYBAUTOPSM"
        "Test PSMPs" = "Test-CYBAUTOPSMP"
        "Test CCPs"  = "Test-CCPs"
        "Test PVWAs" = "Test-PVWAs"
    }
    "Applications"          = @{
        "Export Applications" = "Export-ApplicationsList"
    }
    "Privileged Session Management" = @{
        "Export Recording Details" = "Export-RecordingsDetails"
        "Import Connection Component" = "Import-ConnectionComponents"
    }
    "Users & Group Management"          = @{
        "Export Users" = "Export-UsersList"
        "Export Groups" = "Export-GroupsList"
    }
    "Quit"               = @{}
}
