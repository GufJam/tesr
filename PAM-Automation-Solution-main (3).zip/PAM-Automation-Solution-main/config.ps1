$config = @{
    SafeValidationRegex     =  "^(NT|TC|BL|SNT|STC|BC)_[0-9]{7}[P|T|D|L|S]_[^\/:*<>.|?`"%&+]{1,16}$"
    psmps                   =  @("stgplcark0004", "stgplcark0009", "stgtlcark0012", "stgtlcark0014")
    url                     = "https://cyberark-stg.t-mobile.com"
    DefaultManagingCPM      = "PasswordManager"
    AvailableCPMUsers       = @("PasswordManager", "PasswordManagerBL", "CPM_SNT", "CPM_STC")
    DefaultTestSafeName     = 'Test002'
    DefaultVersionRetention = 5
    ArchiveSafeLocation     = '\'

    #CCP related Configurations
    CCP_URLs                = @(
                                'https://stgpwcark000A/AIMWebservice/api/Accounts',
                                'https://stgpwcark001A/AIMWebservice/api/Accounts',
                                'https://stgpwcark002A/AIMWebservice/api/Accounts'
                              )
    IsCerificateRequired    = $true
    Certificate_path        = 'Cert:\LocalMachine\My'
    Cert_Thumbprint         = 'd0d813761616dfaaaf693da7982574296cf4eaf3'
    Object_ccp              = "Operating System-dpollcark0001a-psmpteststg"
    AppID_ccp               = "APP_GIT_102526_CyberArk_STG_agent"
    Safe_ccp                = "NT_0102526S_Cyberark-STG"
    
    PVWA_URLs               = @(
                                'https://stgpwcark000A/AIMWebservice/api/Accounts',
                                'https://stgpwcark001A/AIMWebservice/api/Accounts',
                                'https://stgpwcark002A/AIMWebservice/api/Accounts'
                              )

    #Safe Creation related configutaion
    SafeMembersSearchIn     = 'presidium.com'
    SafeMemberPermGroups    = @{
        OwnerGroup = @{
            ListAccounts                           = $true
            ViewAuditLog                           = $true
            ViewSafeMembers                        = $true
            RequestsAuthorizationLevel1            = $true
        }
        ApproverGroup = @{
            ListAccounts                           = $true
            ViewAuditLog                           = $true
            ViewSafeMembers                        = $true
            RequestsAuthorizationLevel1            = $true
        }
        UserGroup = @{
            ListAccounts                           = $true
            RetrieveAccounts                       = $true
            UseAccounts                            = $true
            UpdateAccountContent                   = $true
            InitiateCPMAccountManagementOperations = $true
            ViewAuditLog                           = $true        
            ViewSafeMembers                        = $true
        }
    }
    
    DefaultSafeMembers      = @(
      @{
        MemberName                             = 'PASAdmin'
        SearchIn                               = 'Vault'
        UseAccounts                            = $true
        RetrieveAccounts                       = $true
        ListAccounts                           = $true
        AddAccounts                            = $true
        UpdateAccountContent                   = $true
        UpdateAccountProperties                = $true
        InitiateCPMAccountManagementOperations = $true
        SpecifyNextAccountContent              = $true
        RenameAccounts                         = $true
        DeleteAccounts                         = $true
        UnlockAccounts                         = $true
        ManageSafe                             = $true
        ManageSafeMembers                      = $true
        BackupSafe                             = $true
        ViewAuditLog                           = $true
        ViewSafeMembers                        = $true
        RequestsAuthorizationLevel1            = $true
        AccessWithoutConfirmation              = $true
        CreateFolders                          = $true
        DeleteFolders                          = $true
        MoveAccountsAndFolders                 = $true
      }, @{
        MemberName                             = 'Vault Admins'
        SearchIn                               = 'Vault'
        ListAccounts                           = $true
        AddAccounts                            = $true
        UpdateAccountContent                   = $true
        UpdateAccountProperties                = $true
        InitiateCPMAccountManagementOperations = $true
        RenameAccounts                         = $true
        DeleteAccounts                         = $true
        UnlockAccounts                         = $true
        ManageSafe                             = $true
        ManageSafeMembers                      = $true
        BackupSafe                             = $true
        ViewAuditLog                           = $true
        ViewSafeMembers                        = $true
        CreateFolders                          = $true
        DeleteFolders                          = $true
      }, @{
        MemberName                             = 'CARK_T2_AppAdmins'
        SearchIn                               = 'Vault'
        ListAccounts                           = $true
        AddAccounts                            = $true
        UpdateAccountContent                   = $true
        UpdateAccountProperties                = $true
        InitiateCPMAccountManagementOperations = $true
        RenameAccounts                         = $true
        DeleteAccounts                         = $true
        UnlockAccounts                         = $true
        ManageSafe                             = $true
        ManageSafeMembers                      = $true
        ViewAuditLog                           = $true
        ViewSafeMembers                        = $true
      }, @{
        MemberName       = 'CARK_Auditors'
        SearchIn         = 'Vault'
        UseAccounts      = $false
        RetrieveAccounts = $false
        ListAccounts     = $true
        ViewAuditLog     = $true
        ViewSafeMembers  = $true
      }
    )
  }
